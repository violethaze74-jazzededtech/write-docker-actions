---
redirect: "https://training.galaxyproject.org/training-material/topics/admin/"
---
