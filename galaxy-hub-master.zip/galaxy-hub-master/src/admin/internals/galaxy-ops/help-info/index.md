 

- [Help Info of C Version GalaxyOps](/src/admin/internals/galaxy-ops/c/index.md) - description of how to use galaxy operations in C

- [Help Info of Python Version GalaxyOps](/src/admin/internals/galaxy-ops/python/index.md) - description of how to use galaxy operations in Python
