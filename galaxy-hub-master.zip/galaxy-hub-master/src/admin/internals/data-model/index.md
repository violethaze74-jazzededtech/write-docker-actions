{{> Admin/LinkBox }}
{{> Develop/LinkBox }}

TODO: Describe data model.  For now, have a picture!

Marten: I use DB Visualizer for the Galaxy's database and it works pretty well. (http://www.dbvis.com/)

<div class='center'>
<a href='/src/admin/internals/data-model/galaxy_schema.png'><img src="/src/admin/internals/data-model/galaxy_schema.png" alt="Galaxy Data Model; click to enlarge" width="600" /></a>

[Galaxy Data Model; click to enlarge](/src/admin/internals/data-model/galaxy_schema.png).
</div>
