---
redirect: "https://docs.galaxyproject.org/en/latest/dev/data_types.html"
---

This page has been migrated to the [Galaxy docs](https://docs.galaxyproject.org/en/latest/dev/data_types.html), please check there for up-to-date information.
