{{> Admin/LinkBox }}

Hub page for [administering](/src/admin/index.md) Galaxy data types.

* [Admin/ReferenceMAFs](/src/admin/reference-mafs/index.md)
* [Adding Completely new Datatypes](/src/admin/datatypes/adding-complete-datatypes/index.md)
* [Subclassing Existing Datatypes](/src/admin/datatypes/adding-datatypes/index.md)
* [Composite Datatypes](/src/admin/datatypes/composite-datatypes/index.md)
