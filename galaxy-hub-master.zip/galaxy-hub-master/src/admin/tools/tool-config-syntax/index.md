{{> Admin/Tools/LinkBox }}

Documentation for the Galaxy tool syntax has been moved to [docs.galaxyproject.org](https://docs.galaxyproject.org/en/latest/dev/schema.html).
