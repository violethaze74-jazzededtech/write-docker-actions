---
title: Running Data Manager Tools using the API
---
See [galaxy-central/scripts/api/data_manager_example_execute.py ](https://bitbucket.org/galaxy/galaxy-central/src/bb0f56f7c6361cf6021da56ce70ca07e0aa6818c/scripts/api/data_manager_example_execute.py?at=default) for an example script.

[Admin/Tools/DataManagers](/src/admin/tools/data-managers/index.md)
