---
title: Strategies for tools that create more than one output file
---

This content has moved to [Planemo's docs](http://planemo.readthedocs.io/en/latest/writing_advanced.html#multiple-output-files).
