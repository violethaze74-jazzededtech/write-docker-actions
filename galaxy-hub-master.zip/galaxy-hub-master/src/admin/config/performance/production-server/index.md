---
redirect: "https://docs.galaxyproject.org/en/latest/admin/production.html"
---

This page has been migrated to the [Galaxy docs](https://docs.galaxyproject.org/en/latest/admin/production.html), please check there for up-to-date references to tutorials.
