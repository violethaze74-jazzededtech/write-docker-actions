---
redirect: "https://docs.galaxyproject.org/en/latest/admin/cluster.html"
---

This page has been migrated to the [Galaxy docs](https://docs.galaxyproject.org/en/latest/admin/cluster.html), please check there for up-to-date information.
