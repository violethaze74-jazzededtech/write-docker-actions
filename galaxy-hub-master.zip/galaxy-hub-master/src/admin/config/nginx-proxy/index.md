---
redirect: "https://docs.galaxyproject.org/en/latest/admin/nginx.html"
---

This page has been migrated to the [Galaxy docs](https://docs.galaxyproject.org/en/latest/admin/nginx.html), please check there for up-to-date information.
