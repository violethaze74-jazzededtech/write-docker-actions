---
redirect: "https://galaxyproject.github.io/training-material/topics/admin/tutorials/heterogeneous-compute/tutorial.html"
---

This document has moved to https://galaxyproject.github.io/training-material/topics/admin/tutorials/heterogeneous-compute/tutorial.html
