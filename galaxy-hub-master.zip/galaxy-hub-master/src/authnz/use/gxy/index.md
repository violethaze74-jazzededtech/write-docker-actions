---
title: Galaxy Username and Password
highlight: true
---

_This is page explains how to use this feature, for admin-specific docs, please refer to [this](/src/authnz/config/gxy/index.md) page._

This is the default and simplest method for creating a 
Galaxy user account, where you would provide Galaxy 
with an email address, a password, and a username.

![image](/src/authnz/use/gxy/01.png)