---
title: "Galaxy : Traitement de données de séquences par Galaxy"
date: '2018-04-10'
days: 1
tease: "détection de SNP, analyse de données RNA-seq et ChIP-seq"
continent: EU
location: "AGROCAMPUS OUEST, Campus de Rennes, France"
location_url: http://formationcontinue.agrocampus-ouest.fr/infoglueDeliverLive/zoom?contentId=12699
external_url: http://formationcontinue.agrocampus-ouest.fr/infoglueDeliverLive/toutes-sessions/programme?idModule=733&nomModule=Galaxy--Traitement-de-donnees-de-sequences-par-Galaxy-module-7/8
image: 
gtn: true
contact: "Yvan Le Bras, Sandrine LAGARRIGUE, formco @ agrocampus-ouest . fr"
---

