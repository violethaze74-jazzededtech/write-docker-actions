---
title: Using Galaxy workflows for metabolomics
date: '2017-02-13'
days: 5
tease: Part of EMBO practical course
continent: EU
location: EMBO Practical Course on Metabolomics Bioinformatics for Life Scientists, Hinxton, United Kingdom
location_url:  https://www.ebi.ac.uk/training/events/2017/embo-practical-course-metabolomics-bioinformatics-life-scientists-3
external_url: https://www.ebi.ac.uk/training/events/2017/embo-practical-course-metabolomics-bioinformatics-life-scientists-3
contact: Etienne Thevenot
---
