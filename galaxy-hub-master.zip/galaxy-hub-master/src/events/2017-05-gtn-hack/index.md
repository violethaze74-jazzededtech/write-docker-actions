---
title: ELIXIR/GOBLET/GTN hackathon for Galaxy training material re-use
tease: Apply by 31 March
date: '2017-05-22'
days: 3
continent: EU
location: University of Cambridge, United Kingdom
image: /images/logos/elixir-uk-trans-440.png
location_url: http://www.cam.ac.uk/
external_url: https://docs.google.com/document/d/1dLCL5-2pkWTvmGTz7GyQkb5LEIZ3FBkPvCBoqUPGUOg/edit
contact: Frederik Coppens
tags: [ cofest ]
---
