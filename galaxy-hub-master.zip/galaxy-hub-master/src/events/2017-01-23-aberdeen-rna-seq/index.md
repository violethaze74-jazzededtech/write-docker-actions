---
title: RNA Sequencing and Differential Expression
date: '2017-01-23'
days: 1
tease: Workshop
continent: EU
location: University of Aberdeen, Scotland, United Kingdom
location_url: http://www.abdn.ac.uk/genomics/bioinformatics/training/
external_url: https://www.abdn.ac.uk/genomics/documents/201617_Workshops/RNA_Sequencing_2017.pdf
gtn: true
contact: Sophie Shaw
image: /src/images/logos/AberdeenLogoTrans.png
---
