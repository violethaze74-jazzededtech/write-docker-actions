---
title: 'NGS & Cancer : Analyses DNA-Seq'
date: '2017-04-19'
days: 3
tease: Analyses DNA-Seq avec Galaxy
continent: EU
location: Cancerpole, Paris, Fance
image: cancerpole.jpg
location_url: http://www.canceropole-idf.fr/
external_url: http://www.canceropole-idf.fr/formation-ngs-dnaseq/
contact: formateurs
---
Apprendre de manière pratique à réaliser un traitement complet de données NGS (Next Generation Sequencing) sur des données ADN au moyen de l’outil Galaxy
