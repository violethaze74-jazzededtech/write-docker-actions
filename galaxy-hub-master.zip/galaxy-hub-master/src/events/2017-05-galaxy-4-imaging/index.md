---
title: Formation Galaxy4Imaging
date: '2017-05-16' 
days: 2
continent: EU
location: Nantes, France
image: /images/logos/IFBSmallTransLogo.png
external_url: http://www.france-bioinformatique.fr/en/evenements/G4I
contact: Comité d'organisation
