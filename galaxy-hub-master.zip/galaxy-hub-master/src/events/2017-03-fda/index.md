---
title: RNA-seq analysis using Galaxy
date: '2017-03-06'
days: 1
tease: a US FDA-sponsored workshop
continent: NA
location: Food and Drug Adminstration (FDA) Washington, D.C., United States
location_url: http://www.fda.gov/
gtn: true
contact: Mo Heydarian, Mallory Freeberg
---
A full-day hands-on Galaxy workshop the includes: An Introduction to Galaxy and Performing RNA-seq Analysis with Galaxy. Hosted by the U.S. Food & Drug Administration.
