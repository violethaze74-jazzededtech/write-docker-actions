---
title: Supporting genomic analysis of diverse organisms using the Galaxy framework
date: '2017-02-22'
days: 1
tease: at the Global Biodiversity Genomics Conference
continent: NA
location:  Global Biodiversity Genomics Conference, Washington, D.C., United States
location_url: http://biogenomics2017.org/
external_url: http://biogenomics2017.org/
contact: James Taylor
---
Additional Resources:
- [A link to the slides](https://speakerdeck.com/jxtx/bio-genomics-2017)
