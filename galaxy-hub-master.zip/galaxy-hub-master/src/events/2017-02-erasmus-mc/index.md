---
title: Galaxy for Translational Research
date: '2017-02-06'
days: 2
tease: at Erasmus Medical Centre
continent: EU
location: Erasmus Medical Centre, Rotterdam, The Netherlands
location_url: https://www.erasmusmc.nl/?lang=en
image: erasmuslogo.png
external_url: https://www.molmed.nl/courses/CourseDetail.asp?courseID=1499&backpage=../courses/courses.asp
contact: Andrew Stubbs
---
The course will focus on using the Galaxy platform (http://galaxyproject.org/) to analyse data from DNAseq and RNAseq experiments and provide the scientist a platform to communicate the output of an analysis back to the research team using iReport in Galaxy. In 2017 we will add a 3rd day on metagenomics analysis.
