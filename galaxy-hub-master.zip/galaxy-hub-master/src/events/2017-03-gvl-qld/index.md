---
title: Galaxy-qld User Group
date: '2017-03-01'
tease: Create a Custom Build for a microbial genome and visualise aligned reads in Trackster
continent: AU
location: St Lucia Campus, University of Queensland, Brisbane. Australia
location_url: https://genomicsvirtuallab.wordpress.com/2017/02/15/next-meeting-of-galaxy-qld-users-is-on-march-1/
external_url: https://genomicsvirtuallab.wordpress.com/2017/02/15/next-meeting-of-galaxy-qld-users-is-on-march-1/
contact: Igor Makunin
gtn: true
---
Additional Resources:
- [Slides](https://dl.dropboxusercontent.com/u/44487329/170301_meetup_custom_genomes.pdf)
