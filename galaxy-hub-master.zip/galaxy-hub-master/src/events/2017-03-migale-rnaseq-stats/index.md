---
title: Analyse statistique de données RNA-Seq - Recherche des régions d'intérêt différentiellement exprimées (R, RStudio et Galaxy)
date: '2017-03-16'
days: 2
tease: Part of Cycle "Bioinformatique par la pratique" 2017
continent: EU
location: Cycle "Bioinformatique par la pratique" 2017, INRA, Jouy-en-Josas, France
image: /images/logos/MIGALELogo.png
location_url: http://migale.jouy.inra.fr/?q=formations
external_url: http://migale.jouy.inra.fr/sites/all/downloads/Migale/Formations/2017/module16.pdf
contact: Christelle Hennequet-Antier, Julie Aubert
---
