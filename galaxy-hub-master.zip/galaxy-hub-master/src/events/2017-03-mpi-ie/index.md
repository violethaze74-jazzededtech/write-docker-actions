---
title: "Galaxy Discovery: do-it-yourself bioinformatics"
date: '2017-03-03'
days: 1
tease: Learn from the best...
continent: EU
location: Max Planck Institute of Immunobiology and Epigenetics, Freiburg, Germany
image: /images/logos/MaxPlanckIIE.png
location_url: http://www.ie-freiburg.mpg.de/
external_url: https://t.co/0dCEj9sLb8
contact: Björn Grüning, Devon Ryan, David Sanin
---
