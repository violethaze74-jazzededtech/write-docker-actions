---
title: CloudLaunch
date: '2017-02-16'
days: 1
tease: Online
continent: GL
location: Online
location_url: /community/galaxy-admins/meetups/2017-02-16/
image: /images/logos/GlasgowPolyomics.jpg
external_url: /community/galaxy-admins/meetups/2017-02-16/
contact: Nuwan Goonasekera, Enis Afgan
---
Additional Resources:
- [Video](https://connect.johnshopkins.edu/p8t92n1zw9q)
