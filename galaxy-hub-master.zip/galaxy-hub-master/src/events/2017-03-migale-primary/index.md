---
title: Analyse primaire de données issues de séquenceurs nouvelle génération sous Galaxy
date: '2017-03-14'
days: 1
tease: Part of Cycle "Bioinformatique par la pratique" 2017
continent: EU
location: Cycle "Bioinformatique par la pratique" 2017, INRA, Jouy-en-Josas, France
image: /images/logos/MIGALELogo.png
location_url: http://migale.jouy.inra.fr/?q=formations
external_url: http://migale.jouy.inra.fr/sites/all/downloads/Migale/Formations/2017/module8bis.pdf
contact: Valentin Loux, Véronique Martin
---
