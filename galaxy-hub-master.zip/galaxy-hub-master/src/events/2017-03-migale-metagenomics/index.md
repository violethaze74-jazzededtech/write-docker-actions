---
title: Analyse de données métagénomiques 16S
date: '2017-03-27'
days: 4
tease: Part of Cycle "Bioinformatique par la pratique" 2017
continent: EU
location: Cycle "Bioinformatique par la pratique" 2017, INRA, Jouy-en-Josas, France
image: /images/logos/MIGALELogo.png
location_url: http://migale.jouy.inra.fr/?q=formations
external_url: http://migale.jouy.inra.fr/sites/all/downloads/Migale/Formations/2017/module20.pdf
contact: Mahendra Mariadassou, Anne-Laure Abraham, Olivier Rué, Sandra Dérozier
---
