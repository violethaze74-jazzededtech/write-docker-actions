---
title: Analyse avancée de séquences
date: '2017-06-06'
days: 3
continent: EU
location: Carreire de l'Université Bordeaux Segalen, Bordeaux, France
image: /src/use/cbib-galaxy/cbib-logo-300.png
location_url: https://www.cbib.u-bordeaux.fr/
external_url: http://cnrsformation.cnrs.fr/stage-17012-Analyse-avancee-de-sequences.html?axe=65
contact: Aurélien Barré, Raluca Uricaru, Benjamin Dartigues 
