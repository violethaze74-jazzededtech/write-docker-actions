---
title: 3rd Galaxy High-Throughput-Sequencing (HTS) data analysis workshop
date: '2017-02-13'
days: 5
tease: at Uni Freiburg
continent: EU
location: Freiburg, DE
location_url: http://www.denbi.de/
image: denbi.png
external_url: http://www.denbi.de/22-training-cat/training-courses/213-3rd-galaxy-high-throughput-sequencing-hts-data-analysis-workshop
contact: Freiburg Galaxy Team
---
1-week full-day hands-on workshop in Freiburg. Topics: Galaxy Introduction, data analysis of: RNA-seq, ChIP-seq, Exome-seq, MethylC-seq.
