---
title:  Introduction to Galaxy - Data Manipulation and Visualisation
date: '2017-03-07'
days: 1
tease: Cambridge, UK, for first time users 
continent: EU
location: Cancer Research UK Cambridge Institute, Cambridge, United Kingdom
image: cambridge.png
location_url: http://www.cambridgecancer.org.uk/
external_url: https://training.csx.cam.ac.uk/bioinformatics/event/2000038
gtn: true
contact: Anne Pajon, Jing Su
---
A Galaxy introduction course covering basic functions, simple data manipulation using use cases and examples and visualisation mostly targeted at first time users.
