---
title: 'Using Galaxy for RNA-seq analysis'
date: '2017-06-29'
days: 1
continent: EU
location: MDC, Berlin, Germany
location_url: 
external_url: http://www.denbi.de/22-training-cat/training-courses/353-bimsb-galaxy-course-using-galaxy-for-rna-seq-analysis
contact: Dilmurat Yusuf, Bora Uyar
---
