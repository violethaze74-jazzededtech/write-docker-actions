---
title: Bioinformatics Workshops on Galaxy and Metagenomics
date: '2017-02-20'
days: 1
tease: Preceding the Global Biodiversity Genomics Conference
continent: NA
location:  Global Biodiversity Genomics Conference, Washington, D.C., United States
location_url: http://biogenomics2017.org/
external_url: https://gigaworkshops.eventbrite.com/
gtn: true
image: giga.jpg
contact: Mallory Freeberg, Mo Heydarian
---
The Galaxy workshop will will introduce genomic data analysis with a differential expression example, using RNA-Seq data and the Galaxy Platform.
