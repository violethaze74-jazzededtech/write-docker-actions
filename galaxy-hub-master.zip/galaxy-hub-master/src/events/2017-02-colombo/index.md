---
title: The Pulse of Cloud Computing with Bioinformatics as an example
date: '2017-02-27'
days: 1
tease: Galaxy presentation at the University of Columbo
continent: AS
location: University of Colombo, Colombo, Sri Lanka
image: /images/logos/u-colombo-small.jpg
location_url: http://www.cmb.ac.lk/
external_url: http://www.cmb.ac.lk/index.php/event/the-pulse-of-cloud-computing-with-bioinformatics-as-an-example/
contact: Nuwan Goonasekera, Enis Afgan
---
