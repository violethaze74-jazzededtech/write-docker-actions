---
title: Traitement de données de séquences par Galaxy
date: '2017-04-07'
days: 1
tease: From Biogenouest in Rennes
continent: EU
location: Rennes, France
image: /images/logos/biogenouest400.jpeg
external_url: https://www.biogenouest.org/RNA-seq%2526microarray#Traitement%20de%20données%20de%20séquences%20par%20Galaxy%20-%201%20jour
---
