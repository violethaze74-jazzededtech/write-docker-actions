---
title: "Experienced specialist in Next Generation Sequencing data analysis"
date: "2021-02-08"
closes: 
summary: "A full position is available for 2 years, and starting at the earliest timepoint possible. This includes working with and running training on the internal Galaxy instance."
continent: EU
location: "Research Core Unit Genomics (RCUG), Hannover Medical School, Hannover, Germany"
image: /src/images/logos/hannover-mh-rcu-logo.jpg
location_url: "https://www.mhh.de/genomics"
external_url: "https://mhh.hr4you.org/job/view/559/experienced-specialist-in-next-generation-sequencing-data-analysis-f-d-m?page_lang=en"
contact: "Oliver Dittrich-Breiholz"
---
