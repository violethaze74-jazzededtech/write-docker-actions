---
title: "Academic Specialist Bioinformatician"
date: "2021-03-26"
closes: "2021-04-19"
summary: "Combine technical understanding with an ability to bring together software engineers and different research groups to optimise workflows and usage on a range of platforms, such as Galaxy Australia and Portable Pipelines (JANIS)."
continent: AU
location: "University of Melbourne, Melbourne, Victoria, Australia"
image: "/src/images/logos/melbourne-bioinformatics.png"
location_url: "https://www.melbournebioinformatics.org.au/"
external_url: "http://jobs.unimelb.edu.au/caw/en/job/904562/academic-specialist-bioinformatician"
contact: ""
---
