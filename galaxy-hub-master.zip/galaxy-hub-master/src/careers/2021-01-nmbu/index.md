---
title: "Postdoctoral research fellow"
date: "2021-01-29"
closes: "2021-03-13"
summary: "Interested in host-microbiome interactions and multi-omic data? We have multiple positions starting in 2021. Projects have fun and interesting EU partners."
continent: EU
location: "MEMO Group, Norwegian University of Life Science, Ås, Norway"
image: /src/images/logos/nmbu-logo.png
location_url: "https://www.nmbu.no/en/research/groups/memo"
external_url: "https://www.jobbnorge.no/en/available-jobs/job/199862/postdoctoral-research-fellow-within-meta-omics-analysis-of-microbial-communities"
contact: ""
---
