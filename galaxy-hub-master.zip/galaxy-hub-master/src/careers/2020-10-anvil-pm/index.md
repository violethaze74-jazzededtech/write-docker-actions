---
title: "AnVIL Project Manager"
date: '2020-10-15'
closes: 
summary: "Provide technical expertise and oversight for the [AnVIL Project](http://anvilproject.org/), which incorporates Galaxy, Bioconductor, Terra, Gen3, and Dockstore into a secure cloud-based software ecosystem for genomic data analysis. "
continent: NA
location: "Johns Hopkins University, Baltimore, Maryland, United States"
image: "/src/images/logos/anvil-logo-text.png"
location_url: ""
external_url: "https://jobs.jhu.edu/job/Baltimore-AnVIL-Project-Manager-MD-21218/682125700/"
contact: ""
---
