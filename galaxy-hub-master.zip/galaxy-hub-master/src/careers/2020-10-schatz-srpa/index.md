---
title: "Sr. Programmer Analyst"
date: '2020-10-15'
closes: 
summary: "The Schatz Lab at Johns Hopkins University is looking for self-driven individuals that can work independently to fill multiple software development positions on the Galaxy Project; and Ambitious individuals to fill a programmer analyst position working on the Galaxy and [AnVIL](https://anvilproject.org/) projects."
continent: NA
location: "Schatz Lab, Johns Hopkins University, Baltimore, Maryland, United States"
image: "/src/images/logos/JohnsHopkinsLogoLarge.gif"
location_url: ""
external_url: "https://jobs.jhu.edu/job/Baltimore-Sr_-Programmer-Analyst-MD-21218/666390700/"
contact: ""
---
