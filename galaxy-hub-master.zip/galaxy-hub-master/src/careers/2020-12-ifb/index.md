---
title: "Ingénieur(e) Développeur / DevOps"
date: "2020-12-15"
closes: "2021-03-01"
summary: "1-year position for a developer to work on [usegalaxy.fr](https://usegalaxy.fr/), focused on the contribution to the development, evolution, deployment and maintenance of the French infrastructure."
continent: EU
location: "French Institute of Bioinformatics (IFB), Roscoff, Strasbourg ou Rennes, France"
image: "/src/images/logos/ifb-logo-text.jpg"
location_url: "https://www.france-bioinformatique.fr/"
external_url: "https://www.france-bioinformatique.fr/ingenieure-developpeur-devops/"
contact: "Gildas Le Corguille, Julien Seiler"
---
