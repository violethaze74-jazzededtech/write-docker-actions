---
title: "Titulada/o superior bioinformática/o"
date: "2021-03-11"
closes: "2021-03-24"
summary: '...para el desarrollo del proyecto: “Utilidad de la biopsia líquida y organoides en el manejo y tratamiento de adenocarcinoma de páncreas: hacia una Medicina de Precisión"...'
continent: EU
location: "Instituto de Investigación Sanitaria INCLIVA, Spain"
image: "/src/careers/2021-03-incliva/incliva-logo-en.png"
location_url: "https://www.incliva.es/"
external_url: "https://inb-elixir.es/jobs/tituladao-superior-bioinformaticao"
contact: ""
---
