---
title: "Communications and Community Outreach Officer"
date: "2021-01-22"
closes: "2021-03-04"
summary: "Efficient and clear communication, and sustainable outreach towards the life sciences community."
continent: EU
location: "ELIXIR Belgium, VIB-UGent Center for Plant Systems Biology, Ghent, Belgium"
image: /src/images/logos/vib-logo-large.jpg
location_url: "https://vib.be/vib-ugent-center-plant-systems-biology"
external_url: "https://jobs.vib.be/j/32498/communications-and-community-outreach-officer"
contact: ""
---
