---
title: "Galaxy Workflow and Software Developers"
date: "2021-02-03"
closes: "2021-03-01"
summary: "Design solutions to synthesize molecules in microorganisms & to implement the sesolutions on robotized workstations."
continent: EU
location: "Galaxy-SynBioCAD team, MICALIS Institute, INRAE & AgroParisTech, Jouy-en-Josas, France"
image: /src/use/synbiocad/synbiocad-visual.png
location_url: "https://www.jfaulon.com/galaxy-synbiocad-portal/"
external_url: "http://www.jfaulon.com/wp-content/uploads/galaxy-engineer-positions_20210125.pdf"
contact: ""
---
