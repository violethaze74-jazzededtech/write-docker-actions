---
title: "Research Engineer Bioinformatics"
date: "2021-02-18"
closes: "2021-04-01"
summary: "A full position is available for 2 years, and starting at the earliest timepoint possible. This includes working with and running training on the internal Galaxy instance."
continent: EU
location: "INSERM - Institut Pasteur de Lille, Lille, France"
image: /src/images/logos/inserm-logo-big-trans.png
location_url: "http://www.nord-ouest.inserm.fr/"
external_url: "http://www.idf.inserm.fr/newsletter/uri/37d9fe04cbfdf9cbfef9fbf801d306ce0909ced40007feffd5d006f9fe28cd31fd050302d504ffd5fe2eff00fdd003d20234d3d30034fefed4d106fb012bcd3001d503fdd033fe0202fefffbfdd503cd0703d3d20004fefcd5d105fefd2dd130010503fdd401fa02022f00fcfdd104cf0703cf000005fd04d4cf05010100d10002d103fed033fbd0fff9fcf9facd02020601d3d30035fd04d40105ff012dd2fd010302fcd501fed702fc00f9fdd104cf0604d3cb0101fdfed4d405fe012cd10201d80230d402fed303fb"
contact: "Julie Dubois-Chevalier"
---
