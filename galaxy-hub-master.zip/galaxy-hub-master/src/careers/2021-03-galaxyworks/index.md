---
title: "Computational Biologist"
date: "2021-03-08"
closes: 
summary: "Solving practical tasks for our clients that span different analysis techniques, require understanding of the tools, data, and biology."
continent: NA
location: "GalaxyWorks, Baltimore (or remote), Maryland, United States"
image: "/src/images/logos/galaxyworks-logo.png"
location_url: "https://galaxyworks.io/"
external_url: "https://galaxyworks.io/careers/"
contact: ""
---
