Placeholder for future work on a 2016 GSOC proposal.
