---
redirect: "https://github.com/galaxyproject/galaxy/blob/dev/CONTRIBUTING.md"
---

This page has been migrated to the [galaxy GitHub repository](https://github.com/galaxyproject/galaxy/blob/dev/CONTRIBUTING.md), please check there for up-to-date information.
