{{> Develop/LinkBox }}

## Galaxy Architecture

Check out the [Galaxy Code Architecture](https://training.galaxyproject.org/training-material/topics/dev/tutorials/architecture/slides.html#1) slides for the most up-to-date documentation on Galaxy code architecture.

For an older architectural overview presented at the 2013 Galaxy Community Conference please see the following video: http://vimeo.com/82179199.
