{{> Documents/LinkBox }}

Common place to attach posters in the [Documents](/src/documents/index.md) hierarchy.

## Posters

PLACEHOLDER_ACTION(AttachFile, Attach a new file.)

PLACEHOLDER_ATTACH_LIST
