{{> Documents/LinkBox }}

Common place to attach papers in the [Documents](/src/documents/index.md) hierarchy.

## Papers

PLACEHOLDER_ACTION(AttachFile, Attach a new file.)

PLACEHOLDER_ATTACH_LIST
