{{> Documents/LinkBox }}

Common page structure for attached documents that are likely to be linked to from more than one page.  See also [Images](/src/images/index.md).

* [Galaxy Project Documents](/src/documents/Galaxy Project/index.md)
* [Papers](/src/documents/papers/index.md)
* [Presentations](/src/documents/presentations/index.md)
* [Posters](/src/documents/posters/index.md)
* [Videos](/src/documents/videos/index.md)

## Other Documents

PLACEHOLDER_ACTION(AttachFile, Attach a file to this page.)

PLACEHOLDER_ATTACH_LIST
