Presentations given at [GAW2014](/src/events/gaw2014/index.md).

PLACEHOLDER_ATTACH_LIST
