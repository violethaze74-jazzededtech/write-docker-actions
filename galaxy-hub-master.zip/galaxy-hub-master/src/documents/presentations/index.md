{{> Documents/LinkBox }}

Common place to attach presentations in the [Documents](/src/documents/index.md) hierarchy.

Also see these subdirectories for specific events:

* [GCC2013](/src/documents/presentations/gcc2013/index.md)
* [GCC2012](/src/documents/presentations/gcc2012/index.md)

## Presentations

PLACEHOLDER_ACTION(AttachFile, Attach a new file.)

PLACEHOLDER_ATTACH_LIST
