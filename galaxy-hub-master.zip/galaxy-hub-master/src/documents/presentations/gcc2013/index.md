Presentations given at [GCC2013](/src/events/gcc2013/index.md).  See also [the Training Day page](/src/events/gcc2013/training-day/index.md).

PLACEHOLDER_ATTACH_LIST
