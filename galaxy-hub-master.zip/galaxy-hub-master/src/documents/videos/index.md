{{> Documents/LinkBox }}

Common place to attach videos in the [Documents](/src/documents/index.md) hierarchy.

## Videos

PLACEHOLDER_ACTION(AttachFile, Attach a new file.)

PLACEHOLDER_ATTACH_LIST
