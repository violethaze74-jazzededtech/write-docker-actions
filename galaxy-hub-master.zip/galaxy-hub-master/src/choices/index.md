---
title: "Galaxy Choices"
redirect: "/use/#which-platform-platform-type-to-choose"
---
