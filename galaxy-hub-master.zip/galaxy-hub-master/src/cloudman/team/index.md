# People

[CloudMan](http://usecloudman.org) is developed by the [Taylor lab](http://taylorlab.org) at [Johns Hopkins University](http://www.jhu.edu), [Nekrutenko lab](http://nekrut.bx.psu.edu) in the [Center for Comparative Genomics and Bioinformatics at Penn State ](http://www.bx.psu.edu), and [CIR](http://www.irb.hr/en/cir/) at the [Ruđer Bošković Institute(RBI)](http://www.irb.hr/en) along with contributions from the community.

## CloudMan Team from A to Z

<table>
  <tr>
    <td> <a href='/src/people/enis-afgan/index.md'><img src="/src/cloudman/team/EnisAfgan.jpg" /></a> <br /> <a href='http://cloudman.irb.hr/enis/'>Enis Afgan</a> <br /> <a href='http://www.irb.hr/en/cir/'>RBI</a> </td>
    <td> <img src="/src/cloudman/team/dannon.jpg" /> <br /> <a href='/src/people/dannon-baker/index.md'>Dannon Baker</a> <br /> <a href='http://www.jhu.edu'>Johns Hopkins</a> </td>
    <td> <img src="/src/cloudman/team/TomislavLipic.jpg" /> <br /> Tomislav Lipic <br /><a href='http://www.irb.hr/en/cir/'>RBI</a> </td>
    <td> <img src="/src/galaxy-team/james.jpg" /> <br /> <a href='/src/people/james-taylor/index.md'>James Taylor</a> <br /> <a href='http://www.jhu.edu'>Johns Hopkins</a> </td>
  </tr>
</table>
