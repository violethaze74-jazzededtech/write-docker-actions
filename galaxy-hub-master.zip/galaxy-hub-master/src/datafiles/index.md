{{> Datafiles/LinkBox }}

Hub page for example data files that are hung off this wiki.  See [Documents](/src/documents/index.md) and [Images](/src/images/index.md) for those types of files.

* [Mouse ChIP-Seq Data](/src/datafiles/mouse-chip-seq-data/index.md) example files
