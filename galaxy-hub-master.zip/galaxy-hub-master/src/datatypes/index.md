see [Learn/Datatypes](/src/learn/datatypes/index.md)

moved, deleting this week of 10/19
