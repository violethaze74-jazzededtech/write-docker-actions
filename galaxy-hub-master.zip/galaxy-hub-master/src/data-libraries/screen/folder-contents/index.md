# Library folder view

This interface lists contents of the folder visible to you and allows actions you are permitted to do.

![folder contents](folder-contents.png)
