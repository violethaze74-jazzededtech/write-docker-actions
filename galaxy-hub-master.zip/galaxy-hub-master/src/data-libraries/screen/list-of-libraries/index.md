# List of libraries view

This is the screen that you reach from the top Galaxy menu under 'Shared Data'.

This interface lists all libraries visible to you and allows actions you are permitted to do.

![list of libraries](library-list.png)
