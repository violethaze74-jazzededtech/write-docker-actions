---
autotoc: false
---

<div class='left'><img src="/src/community/arabic/GalaxyArabic400.png" alt="Galaxy Arabic Speaking Community" width="200" /></div>

## Galaxy Arabic Speaking Community (العربية Galaxy)

<div style="direction: rtl">

 هذا مجتمع عربي لمستخدمي جالاكسي يضم أنشطة الجالاكسي كالدورات التدريبيه والنقاشات في المجتمع العربي والمناطق الناطق<br /> بالعربية في العالم كله إذا كنت تتكلم العربية أو تعيش في الوطن العربي يمكنك متابعتنا على تويتر والفيس بوك واشترك في القائم<br /> البريدية

</div>

<br />
The **Galaxy Arabic speaking community** supports Galaxy activity for the Arabic speaking community and Arabic speaking regions of the world.

If you are interested, please [follow @Galaxy_Arabic on Twitter](http://twitter.com/galaxy_arabic), subscribe to the [Galaxy Arabic mailing list](https://lists.galaxyproject.org/lists/galaxy-arabic.lists.galaxyproject.org/), and join the [Galaxy Arabic Facebook group](http://bit.ly/2ek7fTh).

## Other Resources

* Introduction to Galaxy Project presentation in Arabic ([PowerPoint](https://depot.galaxyproject.org/hub/attachments/documents/presenttions/GalaxyProjectIntroArabic.pptx),
 [PDF](https://depot.galaxyproject.org/hub/attachments/documents/presentations/GalaxyProjectIntroArabic.PDF))
