<div class='center'><a href='/src/community/galaxy-admins/index.md'><img src="/src/images/galaxy-logos/GalaxyAdmins.png" alt="GalaxyAdmins" width="220" /></a> 
<div class='title'>2015-10-15 Web Meetup<br /><br />

</div></div>

{{> Community/GalaxyAdmins/LinkBox }}

<table>
  <tr>
    <th> Date </th>
    <td> 15 October 2015 </td>
    <td rowspan=4 style=" border: none;"> </td>
    <td rowspan=4 style=" border: none;"> </td>
  </tr>
  <tr>
    <th> Time </th>
    <td> 5 pm Central European Summer Time<div class='indent'><a href='http://www.timeanddate.com/worldclock/fixedtime.html?msg=GalaxyAdmins+October+2015+Online+Meetup&iso=20151015T17&p1=1229&ah=1&am=15'>See your local time</a> </div>  </td>
  </tr>
  <tr>
    <th> Topics </th>
    <td> <em>Galaxy at Analome – Outreach, Opportunity and Challenges</em><div class='indent'><a href='https://www.linkedin.com/in/davidkovalic'>David Kovalic</a>, <a href='http://analome.com/'>Analome Inc.</a><br /> At Analome Galaxy has found another home and we like it for numerous reasons. In this talk we will present the multifaceted role Galaxy plays at Analome and how it supports ongoing bioinformatics projects while at the same time providing opportunities for social good. </div> <em>News from the Galaxy project</em> <div class='indent'>Galaxy Wiki Replacement: Options, thoughts, and questions<br /></div>  </td>
  </tr>
  <tr>
    <th> Links </th>
    <td> <a href='https://connect.johnshopkins.edu/p5b2674yauc/'>Video</a>, <a href='https://depot.galaxyproject.org/hub/attachments/documents/presentations/GalaxyAdmins201510_GalaxyAtAnalome.pdf'>Galaxy @ Analome Slides</a>, <a href='https://depot.galaxyproject.org/hub/attachments/documents/presentations/GalaxyAdmins201510_WikiReplacement.pdf'>Wiki Replacement Slides</a> </td>
  </tr>
</table>


<br />

*[GalaxyAdmins](/src/community/galaxy-admins/index.md)* is a discussion group for Galaxy community members who are responsible for Galaxy installations. 

## Call Technology

<div class='right'><img src="/src/images/logos/AdobeConnectSquarish.jpg" alt="April 2015 GalaxyAdmina Meetup, Online Conference Room" width="150" /></div>

The  meetup's online conference room will open 15 minutes before the meetup.  The call will use [Johns Hopkins' Adobe Connect server](http://connect.johnshopkins.edu/welcome/), which in turn uses Adobe Flash.  You are encouraged to connect a few minutes early to work out any unexpected bumps.

### Instructions for Participants

* You can ask questions either by *raising your hand* or by typing the question in the chat box.  
  * If you raise your hand, the host will need to recognize you.
  * If you ask a question verbally, please wear headphones.  Not wearing headphones lead to unpleasant feedback.

<div class='center'><img src="/src/community/galaxy-admins/AdobeConnectQuestion.png" alt="" width="100%" /></div>
