<div class='center'><a href='/src/community/galaxy-admins/index.md'><img src="/src/images/logos/GalaxyAdmins.png" alt="GalaxyAdmins" /></a> <div class='title'>2013-01-16 Web Meetup<br /><br />Deploying Production Galaxy Environments on [OpenStack](http://www.openstack.org/) with [CloudBioLinux](http://cloudbiolinux.org/) and CloudMan</div></div>

<br />

{{> Community/GalaxyAdmins/LinkBox }}

The January 2013 [GalaxyAdmins Meetup](/src/community/galaxy-admins/meetups/2013-01-16/index.md) was held Wednesday, January 16, 2013 at 10am US central time.  [John Chilton](https://www.msi.umn.edu/users/chilton) of the [Minnesota Supercomputing Institute](https://www.msi.umn.edu/) covered "Deploying Production Galaxy Environments on [OpenStack](http://www.openstack.org/) with [CloudBioLinux](http://cloudbiolinux.org/) and CloudMan."   

[Greg Von Kuster](/src/people/greg_vonkuster/index.md) also gave a Galaxy Project update.

<table>
  <tr>
    <th> Date </th>
    <td> January 16, 2013 </td>
  </tr>
  <tr>
    <th> Time </th>
    <td> 10 am Central US Time (-6 GMT) </td>
  </tr>
  <tr>
    <th> Presentation </th>
    <td> <em>Deploying Production Galaxy Environments on <a href='http://www.openstack.org/'>OpenStack</a> with <a href='http://cloudbiolinux.org/'>CloudBioLinux</a> and CloudMan</em> </td>
  </tr>
  <tr>
    <th> Presenter </th>
    <td> <a href='https://www.msi.umn.edu/users/chilton'>John Chilton</a>, <a href='https://www.msi.umn.edu/'>Minnesota Supercomputing Institute</a><br /><a href='/src/people/greg_vonkuster/index.md'>Greg Von Kuster</a>, <a href='http://psu.edu/'>Penn State University</a>  </td>
  </tr>
  <tr>
    <th> Links </th>
    <td> <a href='http://bitly.com/prodcloudman-slides'>Presentation @ Prezi.com</a><br /> <a href='http://bitly.com/prodcloudman'>Related Technical Documentation @ ReadTheDocs.org</a><br /> <a href='https://globalcampus.uiowa.edu/play_recording.html?recordingId=1262341808106_1358350669920'>Meetup Recording</a><br /> </td>
  </tr>
</table>
