<div class='center'><a href='/src/community/galaxy-admins/index.md'><img src="/src/images/logos/GalaxyAdmins.png" alt="GalaxyAdmins" /></a> <div class='title'>2012-11-14 Conference Call</div></div>

<br />

{{> Community/GalaxyAdmins/LinkBox }}

<div class='center'>**Note:** Next [GalaxyAdmins](/src/community/galaxy-admins/meetups/index.md) Meetup: [January 16](/src/community/galaxy-admins/meetups/2013-01-16/index.md) <br /> John Chilton on Deploying Galaxy on OpenStack with CloudBioLinux & CloudMan</div>

<br />

Curtis Hendrickson of the [University of Alabama Birmingham's Center for Clinical and Translation Science (UAB CCTS)](http://www.uab.edu/ccts/ResearchResources/BMI/Pages/default.aspx) spoke on *Deploying Galaxy on a shared-node cluster at UAB.*  

<table>
  <tr>
    <th> Date </th>
    <td> November 14, 2012 </td>
  </tr>
  <tr>
    <th> Time </th>
    <td> 10 am Central US Time (-6 GMT) </td>
  </tr>
  <tr>
    <th> Presentation </th>
    <td> <em>Deploying Galaxy on a shared-node cluster at UAB</em> </td>
  </tr>
  <tr>
    <th> Presenter </th>
    <td> Curtis Hendrickson, <a href='http://www.uab.edu/ccts/ResearchResources/BMI/Pages/default.aspx'>UAB CCTS</a> </td>
  </tr>
  <tr>
    <th> Links </th>
    <td> <strong><a href='https://depot.galaxyproject.org/hub/attachments/community/galaxy-admins/meetups/2012-11-14/2012-11-14-GalaxyAtUAB.pdf'>Slides</a></strong><br /> <strong><a href='https://globalcampus.uiowa.edu/play_recording.html?recordingId=1262339408056_1352907180568'>Screencast</a></strong> (Password: 110516; content starts at 3:20) </td>
  </tr>
</table>


<br /><br />

*We also bid farewell to [Ann Black-Ziegelbein of the University of Iowa](https://www.linkedin.com/pub/ann-blackziegelbein/a/166/117).*  Ann has been the driving force behind launching the [GalaxyAdmins](/src/community/index.md) group and has guided it through its first (wildly successful!) 6 months of existence.  Ann is handing over the reigns to her fellow U Iowa colleague Srinivas Maddhi, whose day job is getting Iowa's Galaxy server into production.  

We thank Ann profusely for her contributions, and Srinivas for taking this on.

## Call Technology

We used the University of Iowa's Blackboard system for the call. Some care is needed to avoid getting feedback with participants without headphones. Therefore, *headphones are strongly encouraged.*
