<div class='center'><a href='/src/community/galaxy-admins/index.md'><img src="/src/images/galaxy-logos/GalaxyAdmins.png" alt="GalaxyAdmins" width="220" /></a> 
<div class='title'>2016-02-18 Web Meetup<br /><br />

</div></div>

{{> Community/GalaxyAdmins/LinkBox }}

<table>
  <tr>
    <th> Date </th>
    <td> 18 February 2015 </td>
    <td rowspan=4 style=" border: none;"> </td>
    <td rowspan=4 style=" border: none;"> </td>
  </tr>
  <tr>
    <th> Time </th>
    <td> <a href='http://bit.ly/1nDGAkZ'>5 pm Central European Time</a><div class='indent'><a href='http://bit.ly/1nDGAkZ'>See your local time</a></div> </td>
  </tr>
  <tr>
    <th> Topics </th>
    <td> <em>Automating Galaxy deployment @ artbio.fr: the pros and cons of Ansible</em> (<a href='https://depot.galaxyproject.org/hub/attachments/documents/presentations/201602_Admins_Ansible_vanderbeek.pdf'>Slides</a>)<div class='indent'><a href='http://www.ibps.upmc.fr/fr/IBPS/annuaire/1921-Marius-Van+Den+Beek'>Marius van den Beek</a>, <a href='http://www.ibps.upmc.fr/fr'>Institute de Biologie Paris</a> </div> <em>The Wheels on the Galaxy go round and round: <a href='http://pythonwheels.com/'>Python Wheels</a> in Galaxy </em> (<a href='https://depot.galaxyproject.org/hub/attachments/documents/presentations/201602_Admins_Wheels_Coraor.pdf'>Slides</a>)<div class='indent'><a href='/src/people/nate/index.md'>Nate Coraor</a>, Penn State University</div> </td>
  </tr>
  <tr>
    <th> Links </th>
    <td> <strong><a href='https://connect.johnshopkins.edu/p2ehp5f3p2h/'>Video</a></strong> </td>
  </tr>
</table>


<br />

*[GalaxyAdmins](/src/community/galaxy-admins/index.md)* is a discussion group for Galaxy community members who are responsible for Galaxy installations. 

## Call Technology

<div class='right'><img src="/src/images/logos/AdobeConnectSquarish.jpg" alt="April 2015 GalaxyAdmina Meetup, Online Conference Room" width="150" /></div>

The  meetup's [online conference room](https://connect.johnshopkins.edu/galaxyadmins201602) will open 15 minutes before the meetup.  The call will use [Johns Hopkins' Adobe Connect server](http://connect.johnshopkins.edu/welcome/), which in turn uses Adobe Flash.  You are encouraged to connect a few minutes early to work out any unexpected bumps.

### Instructions for Participants

* You can ask questions either by *raising your hand* or by typing the question in the chat box.  
  * If you raise your hand, the host will need to recognize you.
  * If you ask a question verbally, please wear headphones.  Not wearing headphones lead to unpleasant feedback.

<div class='center'><img src="/src/community/galaxy-admins/AdobeConnectQuestion.png" alt="" width="100%" /></div>
