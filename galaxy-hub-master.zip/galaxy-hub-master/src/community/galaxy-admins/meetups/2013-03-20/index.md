<div class='center'><a href='/src/community/galaxy-admins/index.md'><img src="/src/images/logos/GalaxyAdmins.png" alt="GalaxyAdmins" /></a> 
<div class='title'>2013-03-20 Web Meetup<br /><br />[NBIC Galaxy](http://galaxy.nbic.nl/) at [SURFsara's HPC cloud](https://www.surfsara.nl/)
</div></div>

<br />

{{> Community/GalaxyAdmins/LinkBox }}

<table>
  <tr>
    <th> Date </th>
    <td> March 20, 2013 </td>
  </tr>
  <tr>
    <th> Time </th>
    <td> 10 am Central US Time (-5 GMT) </td>
  </tr>
  <tr>
    <th> Presentations </th>
    <td> <em><a href='http://galaxy.nbic.nl/'>NBIC Galaxy</a> at <a href='https://www.surfsara.nl/'>SURFsara's HPC cloud</a></em><div class='indent'><a href="mailto:hailiang DOT mei AT nbic DOT nl">Hailiang Leon Mei</a><br /><a href='https://depot.galaxyproject.org/hub/attachments/community/galaxy-admins/meetups/2013-03-20/20130320Andromeda.pdf'>Slides</a></div><em>Galaxy Project Update</em><div class='indent'><a href='/src/people/dan/index.md'>Dan Blankenberg</a><br /><a href='https://depot.galaxyproject.org/hub/attachments/community/galaxy-admins/meetups/2013-03-20/20130320GalaxyUpdate.pdf'>Slides</a></div> </td>
  </tr>
  <tr>
    <th> Links </th>
    <td> <a href='https://globalcampus.uiowa.edu/play_recording.html?recordingId=1262344508128_1363788090133'>Screencast</a> </td>
  </tr>
</table>


<br />
[NBIC Galaxy (Andromeda)](http://galaxy.nbic.nl/) was migrated to a HPC cloud hosted by Surfsara in September 2012. This presentation discussed the setup of this HPC cloud and the architecture of our NBIC Galaxy, and shared our experience on the installation of the NBIC Galaxy using the Cloudman scripts. The presentation finished with a list of issues and our possible future plans.

The *Galaxy Project Update* focused on the new release process, and upcoming Data Manager features.

<br /><br />

## Call Technology

We will use the University of Iowa's Blackboard system for the call. **Downloading and launching the required Java application takes a few minutes. Using a headphone with microphone to prevent audio feedback during the call is recommended.**

<br />
