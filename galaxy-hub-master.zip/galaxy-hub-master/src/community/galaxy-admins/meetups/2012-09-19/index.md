---
title: 2012-09-19 Conference Call
---
<div class='center'><a href='/src/community/galaxy-admins/index.md'><img src="/src/images/logos/GalaxyAdmins.png" alt="GalaxyAdmins" /></a></div>

{{> Community/GalaxyAdmins/LinkBox }}



# Links

* [Slides](https://depot.galaxyproject.org/hub/attachments/community/galaxy-admins/meetups/2012-09-19/2012-09-19-Galaxy_Managers-UFL-Moskalenko.pdf): Alex Moskalenko: 2012-09-19-Galaxy_Managers-UFL-Moskalenko.pdf
* [Screencast](https://globalcampus.uiowa.edu/play_recording.html?recordingId=1262330108904_1348060268057): Unfortunately the recording starting a bit late for our up front discussion about logistics (name change/common time).  But it began right after Alex starting his presentation (the important part!). 

## Meeting Summary

We have a new name!  The group formally known as GalaxyCzars is now Galaxy-Admins.  Thank you to Hans-Rudolf Hotz for the winning suggestion - cheers to you Hans-Rudolf!  Thanks to to all the other great and humorous suggestions submitted: GalaxyCaretakers, GalaxyHackers, GalaxySudoers, GalaxyLocals, GalaxyCommons. 




We have set a common meeting time.  We will meet every other month (starting in January) on the third Wednesday of the month at 10 am central time (Chicago, USA). 




Next Meeting - mark your calendars!: November 2012.  The third Wed falls Thanksgiving week, so we are still working on the date. UAB to present (THANK YOU!).




Special thanks to Alex Moskalenko for presenting!

## Next Meeting

The next [conference call](/src/community/galaxy-admins/meetups/2012-09-19/index.md) will happen in November.   We are looking for January Volunteers! If you have a large Galaxy installation, please consider telling the group about it.
