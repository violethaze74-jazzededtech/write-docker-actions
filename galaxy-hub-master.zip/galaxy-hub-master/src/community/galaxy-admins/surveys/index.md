<div class='center'><a href='/src/community/galaxy-admins/index.md'><img src="/src/images/logos/GalaxyAdmins.png" alt="GalaxyAdmins" /></a></div>

{{> Community/GalaxyAdmins/LinkBox }}

Two surveys of the Galaxy developer/deployer/administrator community have been done:

* [Community-wide admin questionnaire from fall 2014](/src/community/galaxy-admins/surveys/2014/index.md). This was part of a pair of questionnaires.  The other asked Galaxy users about their experiences.  There were 28 responses to the admin questionnaire.
* [Initial survey](/src/community/galaxy-admins/surveys/2012/index.md) of GalaxyAdmins membership as part of the group's launch, an online survey was [sent out in May](/src/news/galaxy-czars-survey/index.md).  There were 31 total responses.
