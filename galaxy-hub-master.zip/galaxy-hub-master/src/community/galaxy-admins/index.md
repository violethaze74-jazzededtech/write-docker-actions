---
title: "Galaxy-Admins"
---
<div class='center'><img src="/src/images/galaxy-logos/GalaxyAdmins.png" alt="" width="240" /></div>

{{> Community/GalaxyAdmins/LinkBox }}



*Galaxy-Admins* is a discussion group for Galaxy community members who are responsible for large Galaxy installations.  

Galaxy-Admins was started with [this email thread in April 2012](https://lists.galaxyproject.org/archives/list/galaxy-dev@lists.galaxyproject.org/thread/ON7MIOYB2H4PSXBNTRBFNCTLG4HU7LFR/#5DXKB3GIUGMOZSAM3SPKJ5AN3KBDOBXU). This proposal got a huge response, and thus this group was born.

## Meetups

The group [meets](/src/community/galaxy-admins/meetups/index.md) the third Thursday of every two month (starting February) unless otherwise notified, and irregularly at [Galaxy-related events](/src/events/index.md), such as [GCC2016](https://web.archive.org/web/http://gcc2016.iu.edu/).
