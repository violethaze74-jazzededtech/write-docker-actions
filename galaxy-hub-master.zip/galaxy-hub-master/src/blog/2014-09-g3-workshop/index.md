---
date: '2014-04-24'
title: "All systems go at ICSB 2014 and the Great GigaScience and Galaxy (G3) workshop"
tease: "Tackling irreproducible research"
authors: "Scott Edmunds"
external_url: "http://gigasciencejournal.com/blog/all-systems-go-at-icsb-2014-and-the-great-gigascience-and-galaxy-g3-workshop/"
source_blog_url: "http://gigasciencejournal.com/blog/"
source_blog: "(GIGA)Blog"
---
