---
title: "gProfiler is published and running on usegalaxy.eu"
authors: "Ivan Kuzmin"
tease: "A toolset for functional enrichment analysis and conversions of gene lists."
date: "2019-11-20"
external_url: "https://galaxyproject.eu/posts/2019/11/20/gProfiler/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
