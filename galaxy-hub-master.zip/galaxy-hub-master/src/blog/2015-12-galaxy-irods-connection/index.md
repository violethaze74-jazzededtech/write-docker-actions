---
date: '2015-12-08'
title: "Testing connexion between Galaxy and iRODS"
tease: "Testing the connexion of Galaxy to iRODS object store."
authors: "Mikael Loaec, Olivier Inizan"
external_url: "https://urgi.versailles.inra.fr/content/download/5169/39254/file/galaxy_irods.pdf"
---
