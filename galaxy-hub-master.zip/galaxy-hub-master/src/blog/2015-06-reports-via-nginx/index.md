---
date: '2015-06-02'
title: "Exposing Galaxy reports via nginx in a production instance"
tease: "Outline how I've done this for our local Galaxy set up, which uses nginx."
authors: "Peter Briggs"
external_url: "http://galacticengineer.blogspot.co.uk/2015/06/exposing-galaxy-reports-via-nginx-in.html"
source_blog_url: "http://galacticengineer.blogspot.co.uk/"
source_blog: "Galactic Engineer"
---
