---
date: '2020-04-23'
title: "Multi-omics Visualization Platform: An extensible Galaxy plug-in for multi-omics data visualization and exploration"
authors: "Björn Grüning"
tease: "a visualization plug-in that extends Galaxy-P’s advantages into the visualization of large, complex datasets"
external_url: "https://galaxyproject.eu/posts/2020/04/23/mvp/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
