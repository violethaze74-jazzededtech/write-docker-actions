---
date: '2020-08-13'
title: "Lessons learnt from organizing a virtual conference (BCC2020)"
authors: "BCC2020 Organizers"
tease: ""
external_url: "https://bcc2020.github.io/blog/lessons-learnt"
source_blog: "BCC2020"
source_blog_url: "https://bcc2020.github.io/news/"
---
