---
date: '2017-07-25'
title: "Elixir, CLIMB, Sanger and the Galaxy Community Conference"
tease: "UK, UK, UK, and France"
authors: "Simon Gladman"
external_url: "https://www.melbournebioinformatics.org.au/projects-blog/uk-tour-2017-blog2/"
source_blog_url: "https://www.melbournebioinformatics.org.au/projects-blog/"
source_blog: "Melbourne Bioinformatics Projects Blog"
---
