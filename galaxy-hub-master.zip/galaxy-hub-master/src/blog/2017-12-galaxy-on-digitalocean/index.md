---
date: '2017-12-01'
title: "Setup your own instance of the Galaxy Bioinformatics platform on DigitalOcean"
tease: "Setup a DigitalOcean droplet with Galaxy, Apache and PostgreSQL"
authors: "Vimalkumar Velayudhan"
external_url: "https://vimal.io/setup-your-own-galaxy-bioinformatics-instance-on-digitalocean/"
source_blog_url: "https://vimal.io"
source_blog: "Vimalkumar Velayudhan's Blog"
---
