---
date: '2016-08-24'
title: "Galaxy tools for Constructive Solid Geometry"
tease: "Galaxy CSG flavor"
authors: "Greg Von Kuster"
external_url: "https://github.com/gregvonkuster/galaxy-csg/blob/master/README.md"
source_blog_url: "https://github.com/gregvonkuster/galaxy-csg/"
source_blog: "Greg Von Kuster's GitHub"
---
