---
date: '2018-11-27'
title: "Galaxy Tool Generator (GTG)"
tease: "A web application for developing Galaxy tools through web interfaces"
authors: "Ming Chen"
external_url: "https://galaxy-tool-generator.readthedocs.io/en/latest/"
source_blog: "Staton Lab"
---
