---
date: '2013-07-09'
title: "#usegalaxy lights up northern skies"
tease: "eye-wateringly expensive alcohol, brown cheese and reproducible research at the Galaxy Community Conference in Oslo"
authors: "Scott Edmunds"
external_url: "http://gigasciencejournal.com/blog/usegalaxy-lights-up-northern-skies/"
source_blog_url: "http://gigasciencejournal.com/blog/"
source_blog: "(GIGA)Blog"
---
