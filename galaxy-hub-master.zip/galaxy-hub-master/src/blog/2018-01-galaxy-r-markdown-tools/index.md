---
date: '2018-01-08'
title: "Galaxy R Markdown Tools"
tease: "Using R Markdown as a framework to develop Galaxy tools"
authors: "Ming Chen"
external_url: "https://github.com/statonlab/galaxy-r-markdown-tools"
source_blog: "Staton Lab"
---
