---
title: "Sweden + South Africa Training Update"
authors: "Tomas Klingstrom"
tease: "Agricultural Sciences collaboration between Swedish University of Agricultural sciences researchers and the Agricultural Research Council in South Africa"
date: "2019-11-02"
external_url: "https://galaxyproject.eu/posts/2019/11/02/tomas-klingstroem-training-update/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
