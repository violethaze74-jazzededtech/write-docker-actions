---
title: "Open Life Science program & the Galaxy community"
tease: " involvement in OLS-2 and invitation to apply to the next cohort"
authors: "Beatriz Serrano-Solano, Muhammet Celik "
external_url: "https://galaxyproject.eu/posts/2020/12/22/ols/"
date: "2020-12-22"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
