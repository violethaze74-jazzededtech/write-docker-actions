---
date: '2015-03-17'
title: "Custom Google web searches for Galaxy help"
tease: "Astronomy, phones, sports teams, chocolate, cars.  Not."
authors: "Peter Briggs"
external_url: "http://galacticengineer.blogspot.co.uk/2015/03/custom-google-web-searches-for-galaxy.html"
source_blog_url: "http://galacticengineer.blogspot.co.uk/"
source_blog: "Galactic Engineer"
---
