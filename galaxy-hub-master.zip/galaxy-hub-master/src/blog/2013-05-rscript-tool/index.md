---
date: '2013-05-06'
title: "Creating a Galaxy tool for R scripts that output images and PDFs"
tease: "XML wrapper and R code"
authors: "Samuel Lampa"
external_url: "http://saml.rilspace.com/creating-a-galaxy-tool-for-r-scripts-that-output-images-and-pdfs"
source_blog_url: "http://saml.rilspace.com/" 
source_blog: "Samuel's Tech Blog"
---
