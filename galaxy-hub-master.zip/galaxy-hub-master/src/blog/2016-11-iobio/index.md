---
date: '2016-11-02'
title: "IOBIO Now in Galaxy"
tease: "bam.iobio and vcf.iobio can now be launched directly from galaxy using your data already stored there."
authors: "Chase Miller"
external_url: "http://iobio.io/2016/11/02/galaxy-integration/"
source_blog_url: "http://iobio.io/blog.html"
source_blog: "iobio Blog"
---
