---
date: '2016-06-20'
title: "Running Jobs Outside the Galaxy Docker Container"
tease: "Instructions on how to do this ..."
authors: "Marius van den Beek"
external_url: https://github.com/bgruening/docker-galaxy-stable/blob/dev/docs/Running_jobs_outside_of_the_container.md
source_blog_url: "https://github.com/bgruening/docker-galaxy-stable/tree/dev/docs"
source_blog: "Docker Galaxy Stable Docs"
---
