---
date: '2017-04-25'
title: "Securing Galaxy with HTTPS running with Nginx using Let’s Encrypt"
tease: "Secure communication between a Galaxy instance and its users"
authors: "Peter Briggs"
external_url: "http://galacticengineer.blogspot.co.uk/2017/04/securing-galaxy-with-https-running-with.html"
source_blog_url: "http://galacticengineer.blogspot.co.uk/"
source_blog: "Galactic Engineer"
---
