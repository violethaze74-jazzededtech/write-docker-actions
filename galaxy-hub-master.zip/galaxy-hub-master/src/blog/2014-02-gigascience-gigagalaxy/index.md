---
date: '2014-02-06'
title: "Rewarding Reproducibility: First Papers in our Galaxy Series utilizing our GigaGalaxy platform"
tease: "GigaScience moves toward more interactive articles"
authors: "Scott Edmunds"
external_url: "http://gigasciencejournal.com/blog/rewarding-reproducibility-first-papers-in-our-galaxy-series-utilizing-our-gigagalaxy-platform/"
source_blog_url: "http://gigasciencejournal.com/blog/"
source_blog: "(GIGA)Blog"
---
