---
date: '2013-12-05'
title: "Tool Integration Short Tutorial"
tease: "Documents best practices for tool integration"
authors: "Contributors"
external_url: "http://wiki.sb-roscoff.fr/ifb/index.php/Tool_Integration_Short_Tutorial"
source_blog_url: http://wiki.sb-roscoff.fr/ifb/
source_blog: "IFB Galaxy Work Group Wiki"
---
