---
date: '2015-02-28'
title: "Integrating a Java Program in Galaxy"
tease: "Example showing how to install a Java program as a tool in a Galaxy instance"
authors: "Pierre Lindenbaum"
external_url: "http://plindenbaum.blogspot.com/2015/02/integrating-java-program-in-usegalaxy.html"
source_blog_url: "http://plindenbaum.blogspot.com/"
source_blog: "YOKOFAKUN"
---
