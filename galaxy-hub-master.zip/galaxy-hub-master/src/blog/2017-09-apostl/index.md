---
date: '2017-09-20'
title: "APOSTL -- A staggering number of Galaxy AP-MS tools in a user friendly interface!"
tease: "where all the Galaxy tools for Affiniity purification/enrichment MS experiments are located in a form where we all can use them"
authors: "Ben Orsburn"
external_url: "http://proteomicsnews.blogspot.com/2017/09/apostl-staggering-number-of-galaxy-ap.html"
source_blog_url: "http://proteomicsnews.blogspot.com/"
source_blog: "News in Proteomics Research"
---
