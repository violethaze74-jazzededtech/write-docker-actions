---
title: "Tips and tricks for Galaxy"
tease: '"a useful bag of tricks and tools"'
authors: "Nolan Woods"
external_url: "https://thewoods.blog/Galaxy-tips/"
date: "2021-03-24"
source_blog: "Innovate Invent"
source_blog_url: "https://thewoods.blog/"
---
