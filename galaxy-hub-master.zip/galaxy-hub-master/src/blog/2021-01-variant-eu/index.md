---
title: "New and updated CNV and Variant Calling tools"
tease: "on UseGalaxy.eu and in the Toolshed"
authors: "Wolfgang Maier"
external_url: "https://galaxyproject.eu/posts/2021/01/30/cnv-and-vc-updates/"
date: "2021-01-30"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
