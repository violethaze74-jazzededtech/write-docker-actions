---
date: '2015-03-18'
title: "Installing ANNOVAR in Galaxy"
tease: "A HOWTO for installing ANNOVAR in Galaxy"
authors: "Peter Briggs"
external_url: "http://galacticengineer.blogspot.co.uk/2015/03/installing-annovar-in-galaxy.html"
source_blog_url: "http://galacticengineer.blogspot.co.uk/"
source_blog: "Galactic Engineer"
---
