---
date: '2017-07-31'
title: "Intergalactique – the Galaxy Community Conference 2017"
tease: "a run down of this year's Galaxy Community Conference"
authors: "Hollydawn Murry"
external_url: "https://blog.f1000.com/2017/07/31/intergalactique-the-galaxy-community-conference-2017/"
source_blog_url: "https://blog.f1000.com/blogs/f1000research"
source_blog: "F1000 Research blog"
---
