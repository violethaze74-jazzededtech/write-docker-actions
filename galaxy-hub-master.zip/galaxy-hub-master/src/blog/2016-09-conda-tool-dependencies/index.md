---
date: '2016-09-20'
title: "Conda as a new standard for Galaxy tool dependencies"
tease: "For deployment issues, we need a package manager that is operating system and programming language agnostic..."
authors: "Björn Grüning"
external_url: "http://gigasciencejournal.com/blog/guest-posting-introducing-conda-for-galaxy/"
source_blog_url: "http://gigasciencejournal.com/blog/"
source_blog: "(GIGA)Blog"
---
