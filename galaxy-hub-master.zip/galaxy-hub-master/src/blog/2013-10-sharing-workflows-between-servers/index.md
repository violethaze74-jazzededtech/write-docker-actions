---
date: '2013-10-23'
title: "Sharing workflows between servers"
tease: "Process for sharing workflows, including wrapping necessary tools"
authors: "Contributors"
external_url: "http://wiki.sb-roscoff.fr/ifb/index.php?title=Sharing_workflow_between_labs:_practices"
source_blog_url: "http://wiki.sb-roscoff.fr/ifb" 
source_blog: "IFB Galaxy Work Group Wiki"
---
