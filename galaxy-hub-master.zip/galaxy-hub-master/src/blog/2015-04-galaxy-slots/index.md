---
date: '2015-04-22'
title: "Using GALAXY_SLOTS with multithreaded Galaxy tools"
tease: "Using GALAXY_SLOTS with multithreaded Galaxy tools"
authors: "Peter Briggs"
external_url: "http://galacticengineer.blogspot.co.uk/2015/04/using-galaxyslots-for-multithreaded_22.html"
source_blog_url: "http://galacticengineer.blogspot.co.uk/"
source_blog: "Galactic Engineer"
---
