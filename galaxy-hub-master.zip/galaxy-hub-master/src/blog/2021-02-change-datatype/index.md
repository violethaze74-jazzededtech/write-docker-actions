---
title: "Change a datatype on multiple datasets"
tease: ""
authors: "Dan Blankenberg"
external_url: "https://galaxyworks.io/blog/change-datatype-on-many-datasets"
date: "2021-02-08"
source_blog: "GalaxyWorks Blog"
source_blog_url: "https://galaxyworks.io/blog/"
---
