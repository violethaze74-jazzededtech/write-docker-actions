---
date: '2014-11-27'
title: "Getting Techy With It: GigaScience Technology Update 2014"
tease: 'GigaGalaxy and “bring your own” data parties'
authors: "Nicole Nogoy"
external_url: "http://gigasciencejournal.com/blog/getting-techy-with-it-gigascience-technology-update-2014/"
source_blog_url: "http://gigasciencejournal.com/blog/"
source_blog: "(GIGA)Blog"
---
