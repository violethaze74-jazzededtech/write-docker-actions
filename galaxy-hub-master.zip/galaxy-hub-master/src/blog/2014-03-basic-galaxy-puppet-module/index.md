---
date: '2014-03-28'
title: "Basic Galaxy Puppet Module"
tease: "A puppet module for a very basic galaxy server (use for development)"
authors: "Olivier Inizan, Mikael Loaec"
external_url: "https://forge.puppetlabs.com/urgi/galaxy"
source_blog_url: "https://forge.puppet.com/"
source_blog: "Puppet Forge"
---
