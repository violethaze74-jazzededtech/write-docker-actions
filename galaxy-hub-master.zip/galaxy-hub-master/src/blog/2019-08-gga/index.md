---
date: '2019-08-05'
title: "The Galaxy Genome Annotation Project"
authors: "Björn Grüning"
tease: "Scaling Genome Annotation for the Masses"
external_url: "https://galaxyproject.eu/posts/2019/08/05/gga/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
