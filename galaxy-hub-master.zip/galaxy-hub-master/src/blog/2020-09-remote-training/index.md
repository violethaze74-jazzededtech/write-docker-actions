---
date: '2020-09-15'
title: "Remote training using Galaxy"
authors: "Alireza Khanteymoori, Björn Grüning, and Beatriz Serrano-Solano"
tease: "Lessons learned from our ELIXIR Galaxy Machine Learning Workshop"
external_url: "https://galaxyproject.eu/posts/2020/09/15/ML-lessons-learned/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
