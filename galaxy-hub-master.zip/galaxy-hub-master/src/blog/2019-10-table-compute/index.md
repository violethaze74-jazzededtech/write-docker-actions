---
title: "Use the power of pandas / numpy to transform tabular datasets on UseGalaxy.eu"
authors: "European Galaxy Team"
tease: "Drop or duplicate given rows or columns from a tabular dataset, filter rows or columns on their properties, replace or transform table elements, ..."
date: "2019-10-23"
external_url: "https://galaxyproject.eu/posts/2019/10/23/pandas-in-galaxy/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
