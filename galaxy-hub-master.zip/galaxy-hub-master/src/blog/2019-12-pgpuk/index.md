---
title: "Reaching for the stars: PGP-UK multi-omics data now also available on Galaxy Europe"
authors: "Stephan Beck"
tease: "Galaxy is particularly useful for anyone seeking training in multi-omics analyses and creating of workflows."
date: "2019-12-18"
external_url: "https://pgpukblog.wordpress.com/2019/12/18/reaching-for-the-stars-pgp-uk-multi-omics-data-now-also-available-on-galaxy-europe/"
source_blog: "Personal Genome Project UK blog"
source_blog_url: "https://pgpukblog.wordpress.com/"
---
