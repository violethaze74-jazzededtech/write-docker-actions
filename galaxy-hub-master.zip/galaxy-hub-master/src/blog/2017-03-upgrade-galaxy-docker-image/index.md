---
date: '2017-03-10'
title: " How to upgrade a Galaxy Docker image"
tease: "A step by step guide"
authors: "Rafa Hernández"
external_url: "https://github.com/bgruening/docker-galaxy-stable#Upgrading-images"
source_blog_url: "https://github.com/bgruening/docker-galaxy-stable"
source_blog: "Docker Galaxy Stable Docs"
---
