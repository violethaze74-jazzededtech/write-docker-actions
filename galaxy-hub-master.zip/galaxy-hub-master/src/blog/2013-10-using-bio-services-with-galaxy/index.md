---
date: '2013-10-12'
title: "Using BioServices Python Library with Galaxy"
tease: "A HOWTO on linking BioServices and Galaxy"
authors: "Thomas Cokelaer"
external_url: "http://pythonhosted.org/bioservices/applications.html#galaxy"
source_blog_url: "http://pythonhosted.org/bioservices/index.html" 
source_blog: "BioServices Documentation"
---
