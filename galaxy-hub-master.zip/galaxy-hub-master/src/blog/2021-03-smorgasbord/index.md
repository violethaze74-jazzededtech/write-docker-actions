---
title: "GTN Smörgåsbord: A Global Galaxy Course"
tease: "A report on the largest Galaxy event ever."
authors: "Saskia Hiltemann, Helena Rasche"
external_url: "https://gallantries.github.io/posts/2021/03/01/sm%C3%B6rg%C3%A5sbord/"
date: "2021-03-15"
source_blog: "Gallantries Blog"
source_blog_url: "https://gallantries.github.io/posts"
---
