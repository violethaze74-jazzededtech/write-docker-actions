---
date: '2018-08-30'
title: "Mercurial-based tool installation issues in Galaxy 18.05"
tease: 'Seeing "Error cloning repository: [Errno 2] No such file or directory"?'
authors: "Peter Briggs"
external_url: "http://galacticengineer.blogspot.com/2018/08/mercurial-based-tool-installation.html"
source_blog_url: "http://galacticengineer.blogspot.co.uk/"
source_blog: "Galactic Engineer"
---
