---
date: '2017-05-29'
title: "The ungoogleable: Authenticating a Galaxy Portal with Active Directory"
tease: "How to configure Apache to authenticate a user against an LDAP server that requires authentication to search"
authors: "Paul Gordon"
external_url: "http://achri.blogspot.ca/2017/05/the-final-frontier-authenticating.html"
source_blog_url: "http://achri.blogspot.ca/"
source_blog: "ACHRI Bioinformatics"
---
