---
date: '2017-12-11'
title: "Bioinformatic training with the B3Africa project"
tease: "Training using the Galaksio interface"
authors: "Tomas Klingström"
external_url: "https://usegalaxy-eu.github.io/galaxy-freiburg/2017/12/10/b3africa.html"
source_blog_url: "https://usegalaxy-eu.github.io/galaxy-freiburg/"
source_blog: "Freiburg Galaxy Team Blog"
---
