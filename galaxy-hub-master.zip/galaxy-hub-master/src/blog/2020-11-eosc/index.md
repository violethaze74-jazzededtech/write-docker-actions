---
title: "Insights from the first cross-training between EOSC-Life and EOSC-Nordic"
tease: "Galaxy as a common platform"
authors: "Anne Fouilloux"
external_url: "https://www.eosc-nordic.eu/insights-from-the-first-cross-training-between-eosc-life-and-eosc-nordic/"
date: "2020-11-26"
source_blog: "EOSC-Nordic"
source_blog_url: "https://www.eosc-nordic.eu/news-and-articles/"
---
