---
date: '2019-07-08'
title: "22 Months in the Making: New (Carpentries) Genomics Curriculum Release"
authors: "Erin Becker, Francois Michonneau"
tease: "What goes into a major lesson update?"
external_url: "https://carpentries.org/blog/2019/07/genomics-relaunch/"
source_blog: "Carpentries Blog"
---
