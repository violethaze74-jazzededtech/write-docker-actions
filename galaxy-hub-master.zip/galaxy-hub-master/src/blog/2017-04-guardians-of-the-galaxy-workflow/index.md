---
date: '2017-04-28'
title: "Guardians of the Galaxy Workflow"
tease: "Galaxy Series, Volumes 1-12"
authors: "Scott Edmunds"
external_url: "http://gigasciencejournal.com/blog/guardians-of-the-galaxy-workflow/"
source_blog_url: "http://gigasciencejournal.com/blog/"
source_blog: "(GIGA)Blog"
---
