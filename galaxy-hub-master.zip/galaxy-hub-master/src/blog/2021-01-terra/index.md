---
title: "Try out Galaxy in Terra via AnVIL"
tease: "Your own personal Galaxy"
authors: "Geraldine Van der Auwera"
external_url: "https://terra.bio/try-out-galaxy-in-terra/"
date: "2021-01-29"
source_blog: "Terra Blog"
source_blog_url: "https://terra.bio/blog/"
---
