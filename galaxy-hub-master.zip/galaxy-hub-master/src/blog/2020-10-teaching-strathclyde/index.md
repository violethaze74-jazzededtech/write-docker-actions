---
date: '2020-10-14'
title: "Teaching Advanced Microbiology with Galaxy and TIaaS"
authors: "Leighton Pritchard"
tease: "Addressing challenges the global coronavirus pandemic"
external_url: "https://galaxyproject.eu/posts/2020/10/14/tiaas_feedback_Leighton/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
