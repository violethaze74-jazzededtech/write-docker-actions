---
date: '2013-01-01'
title: "Create Galaxy Tool from Taverna 2 Workflow"
tease: "The workflow-to-galaxy Ruby Gem"
authors: "Kostas Karasavvas"
external_url: "http://rubygems.org/gems/workflow-to-galaxy)"
source_blog_url: "http://rubygems.org/)" 
source_blog: "RubyGems.org"
---
