---
date: '2018-02-01'
title: "Coding in the Winter Wonderland: Galaxy Admin Training in Oslo, 2018"
tease: ""
authors: "Arun Decano"
external_url: "https://arundecano.wordpress.com/2018/02/01/coding-in-the-winter-wonderland-galaxy-admin-training-in-oslo-2018/"
source_blog: "arundecano: Research Findings & World Wanderings blog"
source_blog_url: "https://arundecano.wordpress.com/"
---
