---
title: "Trusted CI and SGCI Collaborate to Secure the Galaxy Science Gateway Platform"
tease: "On the path toward Galaxy security compliance"
authors: "Kelli Shute, Enis Afgan"
external_url: "https://blog.trustedci.org/2021/02/trusted-ci-and-sgci-collaborate-to.html"
date: "2021-02-03"
source_blog: "Trusted CI Blog"
source_blog_url: "https://blog.trustedci.org/"
---
