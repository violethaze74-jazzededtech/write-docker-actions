---
title: "Galaxy Admin Training with the Gallantries"
tease: "Lessons learned"
authors: "Helena Rasche"
external_url: "https://gallantries.github.io/posts/2021/02/01/gat/"
date: "2021-02-01"
source_blog: "Gallantries Blog"
source_blog_url: "https://gallantries.github.io/posts"
---
