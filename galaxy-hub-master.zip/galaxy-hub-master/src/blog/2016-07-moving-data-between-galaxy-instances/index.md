---
date: '2016-07-13'
title: "Moving data between Galaxy instances"
tease: "A howto guide on getting data from one instance to another."
authors: "Igor Makunin"
external_url: "https://genomicsvirtuallab.wordpress.com/2016/07/13/moving-data-between-galaxy-instances/"
source_blog_url: "https://genomicsvirtuallab.wordpress.com/"
source_blog: "Genomics Virtual Lab – Queensland"
---

Also linked from primary Support FAQ hub under: [**Datasets and Histories**](/src/support/#datasets-and-histories)
