---
date: '2013-04-10'
title: "Virtualization at URGI"
tease: "Documents creation of virtual machine ISO image"
authors: "Contributors"
external_url: "http://wiki.sb-roscoff.fr/ifb/index.php?title=Virtualisation"
source_blog_url: "http://wiki.sb-roscoff.fr/ifb" 
source_blog: "IFB Galaxy Work Group Wiki"
---

Documents how to [create of virtual machine ISO image](http://wiki.sb-roscoff.fr/ifb/index.php/Virtualisation) for a Galaxy server through launching the server and setting up connections.

Note: The page is in French, but most of the code/config snippets are in English.
