---
date: '2015-12-14'
title: "We Wish You a GigaChristmas: A 2015 Wrap-Up"
tease: 'a summary of our recent technical developments'
authors: "Nicole Nogoy"
external_url: "http://gigasciencejournal.com/blog/wish-gigachristmas-2015-wrap/"
source_blog_url: "http://gigasciencejournal.com/blog/"
source_blog: "(GIGA)Blog"
---
