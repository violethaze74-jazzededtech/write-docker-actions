---
date: '2013-01-25'
title: "Launch a customized modENCODE Galaxy on Amazon Web Services"
tease: "A HOWTO guide"
authors: "Quang Trinh"
external_url: "https://github.com/modENCODE-DCC/Galaxy/blob/master/docs/README.how.to.launch.Galaxy"
source_blog_url: "https://github.com/modENCODE-DCC/Galaxy/" 
source_blog: "modENCODE-DCC: Galaxy GitHub Repo"
---
