---
date: '2018-09-17'
title: "Hybrid training delivers online participatory training to far-reaching venues"
tease: 'Hybrid training delivers online participatory training to far-reaching venues, with Galaxy of course'
authors: "Christina Hall"
external_url: "https://www.embl-abr.org.au/hybrid-training-delivers-online-participatory-training-to-far-reaching-venues/"
source_blog_url: "https://www.embl-abr.org.au/news/"
source_blog: "EMBL-ABR News"
---
