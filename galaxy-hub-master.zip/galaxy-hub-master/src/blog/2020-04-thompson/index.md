---
date: '2020-04-15'
title: "Galaxy Admin 2020 and beyond"
authors: "Michael Thompson"
tease: "Everything about Galaxy is Ansible!"
external_url: "https://www.open-bio.org/2020/04/14/galaxy-admin-2020/"
source_blog: "OBF"
source_blog_url: "https://www.open-bio.org/blog/"
---
