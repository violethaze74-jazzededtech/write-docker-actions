---
date: '2015-10-21'
title: "Galaxy Tool Generating Datasets"
tease: "How to generate dataset collections from a Galaxy tool"
authors: "Steve Cassidy"
external_url: "http://web.science.mq.edu.au/~cassidy/2015/10/21/galaxy-tool-generating-datasets/"
source_blog_url: "http://web.science.mq.edu.au/~cassidy/"
source_blog: "Steve Cassidy's blog"
---
