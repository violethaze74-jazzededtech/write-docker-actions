---
date: '2018-12-27'
title: "Hey Galaxy People! Want easy proteo-transcriptomics!??!"
tease: "QuanTP is a great new gap bridging tool!"
authors: "Ben Orsburn"
external_url: "https://proteomicsnews.blogspot.com/2018/12/hey-galaxy-people-want-easy-proteo.html"
source_blog: "News in Proteomics Research"
---
