---
date: '2017-08-01'
title: "TechBlog: Jupyter Joins the Galaxy"
tease: "Working with data programmatically inside Galaxy"
authors: "Jeffrey Perkel"
external_url: "http://blogs.nature.com/naturejobs/2017/08/01/techblog-jupyter-joins-the-galaxy/"
source_blog_url: "http://blogs.nature.com/naturejobs/"
source_blog: "Naturejobs Blog"
---
