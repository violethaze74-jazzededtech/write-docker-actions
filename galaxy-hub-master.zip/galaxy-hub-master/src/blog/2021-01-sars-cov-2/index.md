---
title: "Variant Analysis of SARS-CoV-2 Sequencing Data"
tease: "January 2021 update"
authors: "Wolfgang Maier, Björn Grüning"
external_url: "https://galaxyproject.eu/posts/2021/01/22/sars-cov-2-variant-analysis/"
date: "2021-01-22"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
