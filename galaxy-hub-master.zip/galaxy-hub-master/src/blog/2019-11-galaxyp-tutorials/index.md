---
date: '2019-11-14'
title: "Great GalaxyP Tutorials hosted at GalaxyProject.eu"
tease: "The arguments are building up for why you need this"
authors: "Ben Orsburn"
external_url: "http://proteomicsnews.blogspot.com/2019/11/great-galaxyp-tutorials-hosted-at.html"
source_blog: "News in Proteomics Research"
source_blog_url: "http://proteomicsnews.blogspot.com/"
---
