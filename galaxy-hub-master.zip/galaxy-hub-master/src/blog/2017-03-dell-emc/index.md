---
date: '2017-03-17'
title: "Galaxy: A Workflow Management System for Modern Life Sciences Research"
tease: "Focus on the data"
authors: "Nathan Bott"
external_url: "http://emergingtechblog.emc.com/galaxy-workflow-management-system-modern-life-sciences-research/"
source_blog_url: "http://emergingtechblog.emc.com/"
source_blog: "Dell EMC Emerging Technologies Blog"
---
