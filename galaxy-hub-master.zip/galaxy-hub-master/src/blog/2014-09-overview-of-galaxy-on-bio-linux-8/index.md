---
date: '2014-09-01'
title: "Overview of Galaxy on Bio-Linux 8"
tease: "Want to run Galaxy under Bio-Linux 8?"
authors: "Tracey Timms-Wilson"
external_url: "http://environmentalomics.org/bio-linux-galaxy/"
source_blog_url: "http://environmentalomics.org/bio-linux/"
source_blog: "The Bio-Linux at the NERC Environmental 'Omics Synthesis Centre series"
---
