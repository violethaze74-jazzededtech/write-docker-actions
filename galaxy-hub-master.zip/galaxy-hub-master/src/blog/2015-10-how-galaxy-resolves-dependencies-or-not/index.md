---
date: '2015-10-09'
title: "How Galaxy resolves tool dependencies (or not)"
tease: "Explanation of Galaxy's tool dependency definitions that specify how to source the actual packages that implement the tool’s commands"
authors: "Peter van Heusden"
external_url: "http://pvh.wp.sanbi.ac.za/2015/10/09/how-galaxy-resolves-dependencies-or-not/"
source_blog_url: "http://pvh.wp.sanbi.ac.za/"
source_blog: "low order magic"
---
