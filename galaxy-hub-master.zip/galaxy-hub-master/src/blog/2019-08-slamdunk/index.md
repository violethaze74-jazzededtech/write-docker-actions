---
date: '2019-08-17'
title: "Slamdunk"
authors: "Tobias Neumann"
tease: "SLAMseq analysis for nucleotide-conversion sequencing datasets"
external_url: "https://galaxyproject.eu/posts/2019/08/17/Slamdunk/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
