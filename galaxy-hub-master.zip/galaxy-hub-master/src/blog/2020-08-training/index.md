---
date: '2020-08-28'
title: "Bioinformatics training in Africa during the COVID-19 pandemic"
authors: "Peter van Heusden"
tease: "Bioinformatics online"
external_url: "https://depot.galaxyproject.org/hub/attachments/blog/2020-08-training/sasbi-newsletter-202008.pdf#page=3"
source_blog: "SASBi News"
source_blog_url: "http://sasbi.weebly.com/"
---
