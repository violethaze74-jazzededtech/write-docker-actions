---
date: '2020-08-22'
title: "3 steps to get your tool into Galaxy"
authors: "Björn Grüning and Beatriz Serrano-Solano"
tease: "A real-world example"
external_url: "https://galaxyproject.eu/posts/2020/08/22/three-steps-to-galaxify-your-tool/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
