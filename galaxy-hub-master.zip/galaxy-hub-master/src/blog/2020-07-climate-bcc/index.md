---
date: '2020-07-27'
title: "Climate Science at BCC2020"
authors: "Anne Fouilloux"
tease: "July has been a very busy month for Galaxy Climate"
external_url: "https://galaxyproject.eu/posts/2020/07/27/climate-at-bcc/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
