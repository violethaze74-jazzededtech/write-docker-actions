---
date: '2016-03-03'
title: "Setting up Galaxy with TORQUE on AWS"
tease: "A basic guide on how to setup Galaxy with TORQUE in an EC2 instance"
authors: "Alex Kanterakis"
external_url: https://gist.github.com/kantale/b7fecd62da22a1523aa2
source_blog_url: "https://gist.github.com/kantale"
source_blog: "Alexandros Kanterakis's Gist"
---
