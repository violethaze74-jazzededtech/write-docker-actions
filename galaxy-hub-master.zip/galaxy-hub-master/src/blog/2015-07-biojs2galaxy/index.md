---
date: '2015-07-12'
title: "BioJS2Galaxy - A step by step guide"
tease: "A simple step by step guide on how to use Sebastian Wilzbach’s application, biojs2galaxy."
authors: "Benedikt Rauscher, Benjamen White"
external_url: "http://www.benjamenwhite.com/2015/07/biojs2galaxy-a-step-by-step-guide/"
source_blog_url: "http://www.benjamenwhite.com"
source_blog: "Benjamen White's Blog"

---
