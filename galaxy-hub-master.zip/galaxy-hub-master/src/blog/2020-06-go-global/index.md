---
date: '2020-06-29'
title: "Go global and go affordable"
authors: "Emily Lescak"
tease: "How BCC2020 went online"
external_url: "https://eventfund.codeforscience.org/go-global-and-go-affordable/"
source_blog: "Code for Science & Society Blog"
source_blog_url: "https://eventfund.codeforscience.org/blog/"
---
