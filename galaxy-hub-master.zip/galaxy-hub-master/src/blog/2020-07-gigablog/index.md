---
date: '2020-07-27'
title: "Birthdays and Online Conferences go Viral. ISMB2020 & BCC2020 in the time of COVID-19"
authors: "Chris Armit"
tease: "Meetings In the Time of Coronavirus: Conferences go Viral"
external_url: "http://gigasciencejournal.com/blog/conferences-go-viral/"
source_blog: "GIGABlog"
source_blog_url: "http://gigasciencejournal.com/blog"
---
