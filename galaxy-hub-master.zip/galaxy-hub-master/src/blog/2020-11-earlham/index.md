---
date: '2020-11-20'
title: "Accessible single-cell RNA-sequencing bioinformatics training using Galaxy"
authors: "Peter Bickerton"
tease: ""
external_url: "https://www.earlham.ac.uk/articles/accessible-single-cell-rna-sequencing-bioinformatics-training-using-galaxy"
source_blog: "Earlham Institute"
source_blog_url: "https://www.earlham.ac.uk/articles/"
---
