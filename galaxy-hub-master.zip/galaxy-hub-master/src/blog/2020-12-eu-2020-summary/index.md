---
title: "The European Galaxy Server in 2020"
tease: "What a shitty year! But it’s over and we hope you and your family are safe and healthy."
authors: "Beatriz Serrano-Solano, Björn Grüning"
external_url: "https://galaxyproject.eu/posts/2020/12/31/balance-2020/"
date: "2020-12-31"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
