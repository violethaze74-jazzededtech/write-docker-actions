---
date: '2019-08-06'
title: "Galaxy Community Conference"
authors: "Anika Erxleben, Helena Rashce, Björn Grüning"
tease: "A brief summary"
external_url: "https://galaxyproject.eu/posts/2019/08/06/gcc/"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/freiburg/news"
---
