---
title: "Activity report of the last 5 years of the Freiburg Galaxy Team"
tease: "Crucial infrastructure  serving more than 22,000 researchers"
authors: "Freiburg Galaxy Team"
external_url: "https://galaxyproject.eu/posts/2020/11/24/5years-report/"
date: "2020-11-24"
source_blog: "UseGalaxy.eu"
source_blog_url: "https://galaxyproject.eu/news"
---
