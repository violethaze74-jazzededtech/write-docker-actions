---
date: '2013-10-27'
title: "IGV Integration"
tease: "How to set up IGV-Galaxy integration in Apache and Galaxy, including adding custom genomes"
authors: "Sarah Maman, Nabihoudine Ibou"
external_url: "http://wiki.sb-roscoff.fr/ifb/index.php/IGV_Integration"
source_blog_url: "http://wiki.sb-roscoff.fr/ifb" 
source_blog: "IFB Galaxy Work Group Wiki"
---
