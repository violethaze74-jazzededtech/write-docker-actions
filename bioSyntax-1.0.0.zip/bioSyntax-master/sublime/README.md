![bioSyntax Logo](https://github.com/bioSyntax/bioSyntax/raw/master/bioSyntax_logo.png)

## ( sublime Submodule )

# See: [bioSyntax Repository](https://github.com/bioSyntax/bioSyntax)

Syntax highlighting for computational biology (in sublime). This repository is for automated installation in package control only.

