![bioSyntax Logo](https://github.com/bioSyntax/bioSyntax/raw/master/bioSyntax_logo.png)
                                                                                                                                                             
## ( vim Submodule )                                                      
                                                                                
# See: [bioSyntax Repository](https://github.com/bioSyntax/bioSyntax)       

Syntax highlighting for computational biology (in vim). This repository is for automated installation only.      
