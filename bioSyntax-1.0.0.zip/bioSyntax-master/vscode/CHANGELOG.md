# Change Log

## [Uneleased]

## [0.0.8], [0.0.9] - 2018-07-12
Automatically activate the theme settings.

## [0.0.7] - 2018-06-02
Background highlight for sam files.

## [0.0.6] - 2018-06-02
Background highlight for fasta and fastq files.

## [0.0.5] - 2018-05-26
Update CHANGELOG

## [0.0.4] - 2018-05-26
Background highlight for Clustal files.

## [0.0.3] - 2018-05-25
Lower the requirement for VS Code's version

## [0.0.2] - 2018-05-24
Better matching patterns for fastq files

## [0.0.1] - 2018-05-23
- Initial release