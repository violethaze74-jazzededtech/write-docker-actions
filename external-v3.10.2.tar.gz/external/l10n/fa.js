OC.L10N.register(
    "external",
    {
    "Select an icon" : "یک آیکون انتخاب کنید",
    "All languages" : "همه زبانها",
    "__language_name__" : "فارسى",
    "Name" : "نام",
    "URL" : "آدرس",
    "Language" : "زبان",
    "Groups" : "گروه ها",
    "Redirect" : "تغییر مسیر",
    "Remove site" : "حذف سایت",
    "New site" : "سایت جدید",
    "Uploading…" : "در حال آپلود...",
    "Reloading icon list…" : "در حال بارگذاری مجدد لیست ایکون...",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "علاوه بر این به خاطر داشته باشید که امروزه بسیاری از سایت ها امکان iframing را به دلایل امنیتی غیرفعال کرده اند .",
    "Icons" : "آیکون ها",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "لطفا به خاطر داشته باشید که اگر شما https را فعال کرده اید برخی از مرورگر ها شما را از نمایش سایت ها با http منع خواهند کرد."
},
"nplurals=2; plural=(n > 1);");
