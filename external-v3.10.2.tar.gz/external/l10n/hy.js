OC.L10N.register(
    "external",
    {
    "__language_name__" : "Հայերեն",
    "Name" : "Անուն",
    "URL" : "URL",
    "Language" : "Լեզու",
    "Groups" : "Խմբեր",
    "Remove site" : "Ջնջել կայքը",
    "Icons" : "լոգոտիպներ"
},
"nplurals=2; plural=(n != 1);");
