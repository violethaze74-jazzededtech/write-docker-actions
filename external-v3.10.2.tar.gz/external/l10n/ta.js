OC.L10N.register(
    "external",
    {
    "__language_name__" : "தமிழ்",
    "Name" : "பெயர்",
    "URL" : "URL",
    "Language" : "மொழி",
    "Groups" : "குழுக்கள்",
    "Remove site" : "தளத்தை அகற்றுக"
},
"nplurals=2; plural=(n != 1);");
