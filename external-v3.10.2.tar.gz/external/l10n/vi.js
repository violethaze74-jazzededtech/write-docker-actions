OC.L10N.register(
    "external",
    {
    "All languages" : "Tất cả ngôn ngữ",
    "No file uploaded" : "Không có tệp nào được tải lên",
    "__language_name__" : "Tiếng Việt",
    "Name" : "Tên",
    "URL" : "URL",
    "Language" : "Ngôn ngữ",
    "Groups" : "Nhóm",
    "Remove site" : "Xóa URL",
    "Uploading…" : "Đang tải lên…"
},
"nplurals=1; plural=0;");
