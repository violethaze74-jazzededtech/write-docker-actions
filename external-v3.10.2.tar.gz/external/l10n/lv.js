OC.L10N.register(
    "external",
    {
    "Select an icon" : "Izvēlies ikonu",
    "All languages" : "Visas valodas",
    "User quota" : "Lietotāja apjoms",
    "No file uploaded" : "Nav augšupielādēta datne",
    "__language_name__" : "Latviešu",
    "Name" : "Nosaukums",
    "URL" : "URL",
    "Language" : "Valoda",
    "Groups" : "Grupas",
    "Devices" : "Ierīces",
    "Icon" : "Ikona",
    "Redirect" : "Novirzīt",
    "Remove site" : "Izņemt vietni",
    "Delete icon" : "Noņemt ikonu",
    "Uploading…" : "Augšupielādē...",
    "Icons" : "Ikonas",
    "Upload new icon" : "Augšupielādēt jaunu ikonu"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
