OC.L10N.register(
    "external",
    {
    "All languages" : "Barcha tillar",
    "Name" : "Ism...",
    "Groups" : "Guruhlar",
    "Uploading…" : "Yuklanmoqda..."
},
"nplurals=1; plural=0;");
