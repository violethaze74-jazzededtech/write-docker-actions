OC.L10N.register(
    "external",
    {
    "Select an icon" : "İkonu seç",
    "__language_name__" : "Azərbaycan dili",
    "Name" : "Ad",
    "URL" : "URL",
    "Language" : "Dil",
    "Groups" : "Qruplar",
    "Remove site" : "Saytı sil",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "Bundan başqa diqqetli olun ona görə ki, hal-hazırda çoxlu saytlar iframing-i təhlükəsizliyə görə qəbul etmir.",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "Nəzərə alın ki, əgər siz HTTPS ilə işləyirsinizsə bəzi browserlər HTTP ilə gələn kontenti blok edəcək."
},
"nplurals=2; plural=(n != 1);");
