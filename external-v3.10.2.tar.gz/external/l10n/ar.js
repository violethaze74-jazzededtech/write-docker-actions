OC.L10N.register(
    "external",
    {
    "All languages" : "كافة اللغات",
    "Header" : "الرأسية",
    "User quota" : "حصة المستخدم",
    "All devices" : "كافة الأجهزة",
    "No file uploaded" : "لم يتم رفع الملف",
    "__language_name__" : "اَللُّغَةُ اَلْعَرَبِيَّة",
    "Name" : "اسم",
    "URL" : "عنوان الموقع",
    "Language" : "اللغة",
    "Groups" : "الفِرَق",
    "Devices" : "الأجهزة",
    "Icon" : "الأيقونة",
    "Redirect" : "إعادة توجيه",
    "Remove site" : "ازل الموقع",
    "New site" : "موقع جديد",
    "Uploading…" : "يتم الرفع…",
    "Icons" : "الأيقونات",
    "Upload new icon" : "إرسال أيقونة جديدة"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
