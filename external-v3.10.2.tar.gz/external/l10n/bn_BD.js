OC.L10N.register(
    "external",
    {
    "Select an icon" : "একটি আইকন নির্বাচন কর",
    "__language_name__" : "বাংলা ভাষা",
    "Name" : "নাম",
    "URL" : "URL",
    "Language" : "ভাষা",
    "Groups" : "গোষ্ঠীসমূহ",
    "Remove site" : "সাইট অপসারণ",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "আরো মনে রাখুন যে নিরাপত্তাজনিত কারণে ইদানিং অনেক সাইট iframing অনুমোদন করেনা",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "মনে রাখুন আপনি https চালালে কিছু ব্রাউজার http হয়ে আসা কিছু সাইট পদর্শ ন বাধাগ্রস্ত করতে পারে।"
},
"nplurals=2; plural=(n != 1);");
