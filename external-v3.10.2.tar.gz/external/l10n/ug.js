OC.L10N.register(
    "external",
    {
    "__language_name__" : "ئۇيغۇرچە",
    "Name" : "ئاتى",
    "URL" : "URL",
    "Language" : "تىل",
    "Groups" : "گۇرۇپپا"
},
"nplurals=2; plural=(n != 1);");
